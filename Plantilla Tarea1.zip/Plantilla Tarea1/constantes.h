#pragma once

enum estadoJuego { GANO_X , GANO_O, EMPATE, JUEGO_EN_CURSO };

#include "constantes.h"
#include "solucion.h"
#include "logica.h"


#include <iostream>
using namespace std;

/*
* Implementar esta función.
* Dependiendo el estado del juego esta debe retornar:  

GANO_X: Si Ha ganado el jugador X
GANO_O: Si Ha ganado el jugador O
EMPATE: Si ya se llenaron todas las casillas y no hay ganador
JUEGO_EN_CURSO: Si el juego aún no se ha terminado.
*/

bool getEmpate(char** tablero){
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            if(tablero[i][j] == '_'){
                return false;}
                    }
                }
                return true;
            }
                
int GetEstado()
{
    /*
    Puedes acceder a las casillas del tablero mediante el arreglo de 
    dos dimensiones tablero.  

    Los índices empiezan en cero, de modo que puedes acceder a la segunda fila, primera columna 
    de la siguiente manera:
    tablero[1][0]
    */
    char** tablero = GetTablero();
    return JUEGO_EN_CURSO;

    for(int i = 0; i < 3; i++){
 //Horizontal X
    if(tablero[i][0] == 'X' && tablero[i][0] == tablero[i][1] && tablero[i][1]
    == tablero[i][2]){
    return GANO_X;
    }
    //Horizontal O
    else if(tablero[i][0] == 'O' && tablero[i][0] == tablero[i][1] &&
    tablero[i][1] == tablero[i][2]){
    return GANO_O;
    }
    //Vertical X
    else if(tablero[0][i] == 'X' && tablero[0][i] == tablero[1][i] &&
    tablero[1][i] == tablero[2][i]){
        return GANO_X;
    }
    //Vertical O
    else if(tablero[0][i] == 'O' && tablero[0][i] == tablero[1][i] &&
    tablero[1][i] == tablero[2][i]){
    return GANO_O;
    }
    }
    //Diagonal derecha izquierda X
    if(tablero[0][2] == 'X' && tablero[0][2] == tablero[1][1] && tablero[1][1]
    == tablero[2][0]){
    return GANO_X;
    } //Diagona derecha izquierda O
    else if(tablero[0][2] == 'O' && tablero[0][2] == tablero[1][1] && tablero[1]
    [1] == tablero[2][0]){
    return GANO_O;
    }//Diagonal izquierda derecha X
    else if(tablero[0][0] == 'X' && tablero[0][0] == tablero[1][1] && tablero[1]
    [1] == tablero[2][2]){
    return GANO_X;
    }//Diagonal izquierda derecha O
    else if(tablero[0][0] == 'O' && tablero[0][0] == tablero[1][1] && tablero[1]
    [1] == tablero[2][2]){
    return GANO_O;
    }//Si no hay empate.
    else if(getEmpate(tablero) != true){
    return JUEGO_EN_CURSO;
    }//Si hay empate.
    else if(getEmpate(tablero)){
    return EMPATE;
    }
    return JUEGO_EN_CURSO;

}

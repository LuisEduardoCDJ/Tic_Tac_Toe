#pragma once

char** GetTablero();
void IniciarTablero();
void Jugar(char jugador, int fila, int columna);
void DesplegarTablero();
void CapturarJugada();
